import "boxicons/css/animations.css";
import "boxicons/css/boxicons.min.css";
import "boxicons/css/transformations.css";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap";
import "./css/styles.css";
import "./css/loader.css";
import "./css/booking.css";