import React, { useCallback, useEffect, useMemo, useState } from "react";
import ReactDOM from "react-dom/client";
import $ from "jquery";
import {
  TextField,
  Rating,
  Typography,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Button,
  Box,
  SxProps,
  Theme,
  Modal,
} from "@mui/material";
import { nanoid } from "nanoid";
import _ from "lodash";
import "./base";

const negativeStyle: SxProps<Theme> = {
  position: "absolute" as "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  boxShadow: 24,
  p: 4,
  borderStyle: "solid",
  borderWidth: "10px",
  borderRadius: "20px",
  borderColor: "red",
};

const positiveStyle: SxProps<Theme> = {
  position: "absolute" as "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  boxShadow: 24,
  p: 4,
  borderWidth: "15px",
  borderRadius: "20px",
  borderColor: "#0b0b45",
  borderStyle: "solid",
};

interface ServiceData {
  id: number;
  type: string;
}

interface CardData {
  name: string;
  image?: string;
}

interface RecommendedServicesPageProps {
  serviceName: string;
}

type ServiceCardProps = {
  name: string;
  imgURL?: string;
  serviceDetails?: Record<string, string>;
};

const dummyImageBase = "https://dummyimage.com/600x400/000/ffffff&text=";

function createTempImage(text: string) {
  return dummyImageBase + encodeURI(text);
}

const ServiceCard = (props: ServiceCardProps) => {
  return (
    <a href="/booking.html" className="card" style={{ width: "15rem" }}>
      <div className="flex-grow-1 d-flex justify-content-center align-items-center">
        <img
          src={props.imgURL ?? createTempImage(props.name)}
          className="card-img-top"
          alt="..."
        />
      </div>
      <div className="card-body flex-grow-0">
        <h5 className="card-title">
          {props.name
            .split(" ")
            .map((text) => _.capitalize(text))
            .join(" ")}
        </h5>
        <button className={"btn btn-primary w-100"} onClick={() => {}}>
          Go To
        </button>
      </div>
    </a>
  );
};

const RecommendedServicesPage = (props: RecommendedServicesPageProps) => {
  const [recommendedServices, setRecommendedServices] = useState<CardData[]>(
    []
  );

  useEffect(() => {
    const data = {
      service: props.serviceName,
      count: 2,
    };
    $.ajax("/api/recommend", {
      method: "POST",
      data: JSON.stringify(data),
      contentType: "application/json",
      complete: (xmlreq) => {
        if (xmlreq.status === 200) {
          const jsonBody = xmlreq.responseJSON;
          if (jsonBody !== undefined) {
            const recommendations: CardData[] = jsonBody.recommendations;
            setRecommendedServices(recommendations);
          }
        }
      },
    });
  }, []);

  const serviceCards = useMemo(() => {
    return recommendedServices.map((data) => {
      return (
        <ServiceCard key={nanoid()} name={data.name} imgURL={data.image} />
      );
    });
  }, [recommendedServices]);

  return (
    <>
      <h2 className="pb-2">We recommend these services for you:</h2>
      <div className="d-flex flex-row justify-content-center gap-4 flex-wrap">
        {serviceCards}
      </div>
    </>
  );
};

const FeedbackForm = () => {
  const [message, setMessage] = useState("");
  const [service, setService] = useState("");
  const [rating, setRating] = useState(4);
  const [serviceTypes, setServiceTypes] = useState<ServiceData[]>([]);
  const [redirected, setRedirected] = useState(false);
  const [completed, setCompleted] = useState(false);

  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [infoText, setInfotext] = useState("");
  const [infoHeader, setInfoHeader] = useState("");
  const [positiveInfo, setPositiveInfo] = useState(false);

  const sendFeedback = () => {
    const data = {
      message: message ?? "",
      serviceType: service,
      rating: rating,
    };
    setLoading(true);
    $.ajax("/api/feedback", {
      method: "POST",
      data: JSON.stringify(data),
      contentType: "application/json",
      complete: (xmlreq) => {
        if (xmlreq.status === 200) {
          setInfoHeader("Thank you!");
          setInfotext("Thank you for your time.");
          setPositiveInfo(true);
          setOpen(true);
          setCompleted(true);
        } else {
          const jsonBody = xmlreq.responseJSON;
          if (jsonBody !== null && jsonBody !== undefined) {
            if (parseInt(jsonBody["status"]) === 3) {
              setInfoHeader("Not allowed");
              setInfotext(
                "You never booked a service from the platform. Before giving feedback please book a service."
              );
              setPositiveInfo(false);
              setOpen(true);
            } else {
              setInfoHeader("Error");
              setInfotext(
                "A problem occured please try again later. Contact with the website admin if it persists."
              );
              setPositiveInfo(false);
              setOpen(true);
            }
          } else {
            setInfoHeader("Error");
            setInfotext(
              "A problem occured please try again later. Contact with the website admin if it persists."
            );
            setPositiveInfo(false);
            setOpen(true);
          }
        }
        setLoading(false);
      },
    });
  };

  useEffect(() => {
    $.ajax("/api/services", {
      complete: (xmlreq, statusText) => {
        if (xmlreq.status === 200) {
          const jsonBody = xmlreq.responseJSON;
          if (jsonBody !== undefined) {
            const services = jsonBody["services"];
            console.log(services);
            setServiceTypes(services);
          }
        }
      },
    });
  }, []);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const serviceId = params.get("serviceId");
    if (serviceId != null) {
      const serviceData = serviceTypes.find(
        (data) => data.id === parseInt(serviceId)
      );
      if (serviceData !== undefined) {
        setService(serviceData.type);
        setRedirected(true);
      }
    }
  }, [serviceTypes]);

  return (
    <>
      <section>
        <div className="px-5 py-5 container rounded rounded-3 my-5 bg-light">
          {completed ? (
            <RecommendedServicesPage serviceName={service} />
          ) : (
            <>
              <h2 className="pb-4">Feedback</h2>
              <form id="react-feedback-form">
                <Typography fontSize={20} paddingBottom={"0.7rem"}>
                  Service you have used
                </Typography>
                <FormControl fullWidth sx={{ marginBottom: "3rem" }}>
                  <InputLabel id="service-select-label">Service</InputLabel>
                  <Select
                    color="success"
                    labelId="service-select-label"
                    id="service-select"
                    value={service}
                    SelectDisplayProps={{
                      style: {
                        display: "flex",
                        alignItems: "center",
                        // justifyContent: "center",
                      },
                    }}
                    label="Service"
                    onChange={(ev) => {
                      const res = ev.target.value as string;
                      setService(res);
                    }}
                    disabled={redirected}
                  >
                    {serviceTypes.map((data) => {
                      return (
                        <MenuItem key={nanoid()} value={data.type}>
                          {_.capitalize(data.type)}
                        </MenuItem>
                      );
                    })}
                  </Select>
                </FormControl>
                <Typography fontSize={20}>Your comment</Typography>
                <TextField
                  color="success"
                  className="rounded rounded-2"
                  multiline
                  rows={4}
                  fullWidth
                  value={message}
                  onChange={(ev) => setMessage(ev.target.value)}
                />
                <Typography fontSize={20} paddingTop={"2rem"}>
                  Ratings
                </Typography>
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                  <Rating
                    name="rating"
                    size="large"
                    defaultValue={3}
                    precision={0.5}
                    value={rating}
                    onChange={(event, newValue) => {
                      if (newValue !== null) {
                        setRating(newValue);
                      }
                    }}
                  />
                </Box>
                <Button
                  fullWidth
                  variant="contained"
                  onClick={() => sendFeedback()}
                  disabled={loading}
                >
                  Submit
                </Button>
              </form>
            </>
          )}
        </div>
      </section>
      <Modal
        open={open}
        onClose={() => setOpen(false)}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={positiveInfo ? positiveStyle : negativeStyle}>
          <Typography id="modal-modal-title" variant="h6" component="h2">
            {infoHeader}
          </Typography>
          <Typography id="modal-modal-description" sx={{ mt: 2 }}>
            {infoText}
          </Typography>
        </Box>
      </Modal>
    </>
  );
};

$(() => {
  Promise.allSettled([]).then(() => {
    $("#load-container").remove();
  });
});

ReactDOM.createRoot($("#react-root")[0]).render(<FeedbackForm />);
