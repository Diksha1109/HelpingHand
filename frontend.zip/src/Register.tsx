import "./base";
import $ from "jquery";
import { Modal } from "bootstrap";

const REGISTER_STATUS_CODES = {
  0: "success",
  1: "Please, try again with a different email address. It is already registered",
  2: "First name or last name is empty",
  3: "Username must contain only numbers and latin characters(min 4, max 25 char)",
  4: "Email is not valid",
  5: "Phone number is not valid",
  6: "Password is not suitable",
};

function updateModalText(header: string, body: string) {
  $("#register-info-modal-title").text(header);
  $("#register-info-modal-body").text(body);
}

const modal = new Modal("#register-info-modal");
$(function () {
  $("#registration-button").on("click", () => {
    $.ajax("/api/register", {
      method: "POST",
      data: $("#registration-button").closest("form").serialize(),

      complete: (xmlreq, status) => {
        const res = xmlreq.responseJSON;
        if (res.status == 0) {
          location.pathname = "/";
        } else if (res.status == 1) {
          updateModalText("Email exists!", REGISTER_STATUS_CODES[1]);
          modal.show();
        } else if (res.status == 2) {
          updateModalText("Empty Field!", REGISTER_STATUS_CODES[2]);
          modal.show();
        } else if (res.status == 3) {
          updateModalText("Username Invalid!", REGISTER_STATUS_CODES[3]);
          modal.show();
        } else if (res.status == 4) {
          updateModalText("Email Invalid!", REGISTER_STATUS_CODES[4]);
          modal.show();
        } else if (res.status == 5) {
          updateModalText("Phone Number Invalid!", REGISTER_STATUS_CODES[5]);
          modal.show();
        } else if (res.status == 6) {
          updateModalText("Email exists!", REGISTER_STATUS_CODES[6]);
          modal.show();
        }
      },
      error: (xmlreq, status) => {
        if (xmlreq.status === 400) {
          updateModalText(
            "Missing Info!",
            "All information is not available in the request!"
          );
          modal.show();
        } else if (xmlreq.status === 500) {
          updateModalText(
            "Server Down!",
            "Server got an error while processing. Please try again in few minutes"
          );
        }
      },
    });
  });
});
