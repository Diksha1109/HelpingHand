import "./base";
import { useCallback, useEffect, useMemo, useState } from "react";
import $ from "jquery";
import ReactDOM from "react-dom/client";
import {
  Box,
  InputAdornment,
  Modal,
  SxProps,
  TextField,
  Theme,
  Typography,
} from "@mui/material";
import "react-datetime/css/react-datetime.css";
import DateTimePicker from "react-datetime";
import _ from "lodash";
import moment from "moment";

type ServiceCardProps = {
  name: string;
  index: number;
  imgURL?: string;
  serviceDetails?: Record<string, string>;
  selectThisService: (serviceID: number) => void;
  selected: boolean;
};

type ServiceData = {
  name: string;
  image?: string;
};

const dummyImageBase = "https://dummyimage.com/600x400/000/ffffff&text=";

const negativeStyle: SxProps<Theme> = {
  position: "absolute" as "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  boxShadow: 24,
  p: 4,
  borderStyle: "solid",
  borderWidth: "10px",
  borderRadius: "20px",
  borderColor: "red",
};

const positiveStyle: SxProps<Theme> = {
  position: "absolute" as "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  boxShadow: 24,
  p: 4,
  borderWidth: "10px",
  borderRadius: "20px",
  borderColor: "green",
  borderStyle: "solid",
};

function createTempImage(text: string) {
  return dummyImageBase + encodeURI(text);
}

const ServiceCard = (props: ServiceCardProps) => {
  return (
    <div className="card" style={{ width: "15rem" }}>
      <div className="flex-grow-1 d-flex justify-content-center align-items-center">
        <img
          src={props.imgURL ?? createTempImage(props.name)}
          className="card-img-top"
          alt="..."
        />
      </div>
      <div className="card-body flex-grow-0">
        <h5 className="card-title">
          {props.name
            .split(" ")
            .map((text) => _.capitalize(text))
            .join(" ")}
        </h5>
        {/* <p className="card-text">{props.}</p> */}
        <button
          className={"btn btn-primary w-100"}
          disabled={props.selected}
          onClick={() => {
            props.selectThisService(props.index);
          }}
        >
          {props.selected ? "Selected" : "Select"}
        </button>
      </div>
    </div>
  );
};

const BookingPage = () => {
  const [loading, setLoading] = useState(false);
  const [searchWord, setSearchWord] = useState("");
  const [selectedService, setSelected] = useState(-1);
  const [currentServiceID, setCurrentServiceID] = useState(-1);
  const [serviceDate, setServiceDate] = useState(
    moment().add(1, "day").toDate()
  );
  const [suggestedServices, setSuggestedServices] = useState<ServiceData[]>([]);

  const [open, setOpen] = useState(false);
  const [infoText, setInfotext] = useState("");
  const [infoHeader, setInfoHeader] = useState("");
  const [positiveInfo, setPositiveInfo] = useState(false);

  const fetchServices = async (wordParam: string) => {
    setLoading(true);
    setSelected(-1);
    const data = {
      service: wordParam,
    };
    $.ajax("/api/recommend", {
      method: "POST",
      data: JSON.stringify(data),
      contentType: "application/json",
      complete: (xmlreq) => {
        if (xmlreq.status === 200) {
          const jsonBody = xmlreq.responseJSON;
          if (jsonBody !== undefined) {
            const recommendations: ServiceData[] = jsonBody.recommendations;
            setSuggestedServices(recommendations);
            setCurrentServiceID(jsonBody.id);
          }
        } else {
          setInfoHeader("Error");
          setInfotext(
            "A problem occured please try again later. Contact with the website admin if it persists."
          );
          setPositiveInfo(false);
          setOpen(true);
        }
        setLoading(false);
      },
    });
  };

  const suggestedServiceCards = useMemo(
    () =>
      suggestedServices.map((suggestedService, index) => {
        return (
          <ServiceCard
            key={index}
            index={index}
            selected={index === selectedService}
            selectThisService={setSelected}
            name={suggestedService.name}
            imgURL={suggestedService.image}
          />
        );
      }),
    [suggestedServices, selectedService]
  );

  const bookService = () => {
    const dateMilis = serviceDate.getTime();
    const serviceName = suggestedServices[selectedService];

    if (dateMilis < Date.now()) {
      setInfoHeader("Wrong Date!");
      setInfotext("Date cannot be before current date");
      setPositiveInfo(false);
      setOpen(true);
    }

    const data = {
      dateMilis: dateMilis,
      serviceName: serviceName,
    };

    $.ajax("/api/book-service", {
      method: "POST",
      data: JSON.stringify(data),
      contentType: "application/json",
      complete: (xmlreq) => {
        if (xmlreq.status === 200) {
          setInfoHeader("Payment Verified!");
          setInfotext("A service is booked on your name.");
          setPositiveInfo(true);
          setOpen(true);
          setTimeout(() => {
            const feedbackURL = new URL(
              `/feedback.html?serviceId=${currentServiceID}`,
              `http://${location.host}`
            );
            console.log(feedbackURL);
            location.assign(feedbackURL);
          }, 5000);
        } else {
          setInfoHeader("Error");
          setInfotext(
            "A problem occured please try again later. Contact with the website admin if it persists."
          );
          setPositiveInfo(false);
          setOpen(true);
        }
        setLoading(false);
      },
    });
  };

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const type = params.get("type") ?? "";
    console.log(type);
    if (type !== "") {
      setSearchWord(type);
      fetchServices(type);
    }
  }, []);
  return (
    <>
      <div className="bg-white">
        <div className="container-md px-0">
          <div className="d-flex align-items-center flex-column">
            <div className="bg-light p-4 booking-container d-flex flex-column w-75 rounded">
              <h2 className="display-6">Book a Service</h2>
              <TextField
                id="search"
                label="Search Service"
                variant="filled"
                className="bg-white rounded-top"
                InputLabelProps={{
                  size: "small",
                }}
                value={searchWord}
                onChange={(ev) => {
                  const newValue = ev.target.value;
                  setSearchWord(newValue);
                }}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <button
                        className="btn btn-primary booking-search-button rounded-0"
                        onClick={() => fetchServices(searchWord)}
                        disabled={loading}
                      >
                        Search
                      </button>
                    </InputAdornment>
                  ),
                }}
              />

              <h5 className="mt-4">When you will require the service ?</h5>
              <DateTimePicker
                className="align-self-start"
                onChange={(value) => {
                  if (typeof value === "string") {
                    return;
                  } else {
                    setServiceDate(value.toDate());
                  }
                }}
                value={serviceDate}
              />
              <div className="d-flex justify-content-between flex-nowrap mt-4">
                <a type="button" className="btn btn-secondary px-3" href="/">
                  Cancel
                </a>
                <button
                  type="button"
                  className="btn btn-success px-3"
                  disabled={selectedService === -1}
                  onClick={() => bookService()}
                >
                  Request Service
                </button>
              </div>
              <p className="text-lg my-3">
                {suggestedServiceCards.length == 0
                  ? "Please type a service name to get suggestions"
                  : "Suggested Services:"}
              </p>
              <div className="d-flex flex-row flex-wrap justify-content-around gap-4">
                {suggestedServiceCards}
              </div>
            </div>
          </div>
        </div>
      </div>
      <Modal
        open={open}
        onClose={() => setOpen(false)}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={positiveInfo ? positiveStyle : negativeStyle}>
          <Typography id="modal-modal-title" variant="h6" component="h2">
            {infoHeader}
          </Typography>
          <Typography id="modal-modal-description" sx={{ mt: 2 }}>
            {infoText}
          </Typography>
        </Box>
      </Modal>
    </>
  );
};

ReactDOM.createRoot($("#react-root")[0]).render(<BookingPage />);
