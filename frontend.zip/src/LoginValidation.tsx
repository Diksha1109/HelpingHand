import $ from "jquery";
import _ from "lodash";
import "./base";

function getAccountDropdownMenu() {
  return `
    <li class="nav-item" id="account-dropdown">
      <a
        id="account-dropdown-menu"
        class="nav-link text-nowrap"
        data-bs-toggle="dropdown"
        href="#"
        >Account<i class="bx bx-chevron-down"></i
      ></a>
      <ul class="dropdown-menu">
        <li><a class="dropdown-item" href="/booking.html">Book a Service</a></li>
        <li><a class="dropdown-item" href="/feedback.html">Rate service</a></li>
        <li><a class="dropdown-item" href="/api/logout">Log out</a></li>
      </ul>
    </li>
  `;
}

function getGreetingNavItem(firstName: string) {
  return `
    <li id="login-nav-item" class="nav-item">
      <a class="nav-item-content text-center text-nowrap" href="#">
        Welcome ${_.capitalize(firstName) ?? "Back"}
      </a>
    </li>
`;
}

$(() => {
  const acc_req = $.ajax("/api/account_info", {
    method: "GET",
    complete: (xmlreq, status) => {
      if (
        xmlreq.status === 200 &&
        xmlreq.getResponseHeader("content-type") == "application/json"
      ) {
        const loginNavItem = $("#login-nav-item");
        const accountDropdown = $("#account-dropdown");
        const baseParent = loginNavItem.parent();
        const json = xmlreq.responseJSON;
        const accountDropdownMenu = getAccountDropdownMenu();
        const greetingNavItem = getGreetingNavItem(json.user.firstName);
        loginNavItem.remove();
        accountDropdown.remove();
        baseParent.append(accountDropdownMenu, greetingNavItem);
      }
    },
  });

  Promise.allSettled([acc_req]).then(() => {
    $("#load-container").remove();
  });
});
