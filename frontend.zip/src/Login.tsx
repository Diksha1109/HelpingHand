import "./base";
import { Modal } from "bootstrap";
import $ from "jquery";

const LOGIN_STATUS_CODES = {
  0: "success",
  1: "Username or password is incorrect please try again!",
};

function updateModalText(header: string, body: string) {
  $("#login-info-modal-title").text(header);
  $("#login-info-modal-body").text(body);
}

const modal = new Modal("#login-info-modal");

$(() => {
  $("#login-button").on("click", () => {
    $.ajax("/api/login", {
      method: "POST",
      data: $("#login-button").closest("form").serialize(),

      complete: (xmlreq, status) => {
        const res = xmlreq.responseJSON;
        if (res.status == 0) {
          location.pathname = "/";
        } else if (res.status == 1) {
          updateModalText("Incorrect Credentials", LOGIN_STATUS_CODES[1]);
          modal.show();
        }
      },
      error: (xmlreq, status) => {
        if (xmlreq.status === 400) {
          updateModalText(
            "Missing Info!",
            "All information is not available in the request!"
          );
          modal.show();
        } else if (xmlreq.status === 500) {
          updateModalText(
            "Server Down!",
            "Server got an error while processing. Please try again in few minutes"
          );
          modal.show();
        }
      },
    });
  });

  Promise.allSettled([]).then(() => {
    $("#load-container").remove();
  });
});
